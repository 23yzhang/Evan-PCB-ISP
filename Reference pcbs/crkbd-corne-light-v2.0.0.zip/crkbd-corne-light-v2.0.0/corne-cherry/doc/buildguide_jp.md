# Build Guide

こちらは Corne Cherry のビルドガイドになります。
バージョンによってビルドガイドは異なりますので、以下よりご自身のものをお選びください。

- [v2 のビルドガイドはこちら](https://github.com/foostan/crkbd/blob/master/corne-cherry/doc/v2/buildguide_jp.md)
- [v3 のビルドガイドはこちら](https://github.com/foostan/crkbd/blob/master/corne-cherry/doc/v3/buildguide_jp.md)
