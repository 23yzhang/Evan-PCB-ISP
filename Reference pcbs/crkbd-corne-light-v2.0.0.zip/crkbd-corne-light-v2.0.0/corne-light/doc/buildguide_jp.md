# Build Guide

こちらは Corne Light のビルドガイドになります。
バージョンによってビルドガイドは異なりますので、以下よりご自身のものをお選びください。

- [v1 のビルドガイドはこちら](https://github.com/foostan/crkbd/blob/master/corne-light/doc/v1/buildguide_jp.md)
- [v2 low-edition のビルドガイドはこちら](https://github.com/foostan/crkbd/blob/master/corne-light/doc/v2/buildguide_low_edition_jp.md)
